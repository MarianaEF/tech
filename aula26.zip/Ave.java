
public class Ave extends Animal{
	Boolean pena ;
	public Ave() {
		
		pena = true;
		// TODO Auto-generated constructor stub
	}
}
