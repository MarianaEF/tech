
public class Lagarto extends Reptil {
	Boolean anda ;

	public Lagarto() {
		
		anda = true;
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Lagarto [anda=" + anda + ", peleFria=" + peleFria + ", alimenta=" + alimenta + ", vive=" + vive
				+ ", respira=" + respira + ", movimenta=" + movimenta + "]";
	}
	
}
