
public class Papagaio extends Ave{
	Boolean voa ;

	public Papagaio() {
		voa = true;
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Papagaio [voa=" + voa + ", pena=" + pena + ", alimenta=" + alimenta + ", vive=" + vive + ", respira="
				+ respira + ", movimenta=" + movimenta + "]";
	}
	
}
