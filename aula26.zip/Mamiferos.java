
public class Mamiferos extends Animal {

	boolean mama;
public Mamiferos() {
	
	mama = true;
	// TODO Auto-generated constructor stub
}
	@Override
	public String toString() {
		return "Mamiferos [mama=" + mama + ", alimenta=" + alimenta + ", vive=" + vive + ", respira=" + respira
				+ ", movimenta=" + movimenta + "]";
	}
	
}
