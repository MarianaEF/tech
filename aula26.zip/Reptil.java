
public class Reptil extends Animal {
	Boolean peleFria ;
	

	public Reptil () {
		peleFria = true;
	}
}
