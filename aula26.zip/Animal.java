
public class Animal {
	boolean alimenta;
	boolean vive;
	boolean respira ;
	boolean movimenta;
	
	public Animal () {
		alimenta = true;
		vive = true;
		respira = true;
		movimenta= true;
	}
}
