import java.util.Locale.LanguageRange;

public class ProgramaRodar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("jack");
		Lagarto jack = new Lagarto();
		jack.anda = true;
		jack.peleFria = true;
		System.out.println(jack);
		System.out.println("***********************");
		
		System.out.println("felipe");
		Homem felipe = new Homem();
		felipe.bipede = true;
		System.out.println(felipe);
		System.out.println("***********************");
		
		System.out.println("marley");
		Cachorro marley = new Cachorro();
		marley.quadrupede = true;
		System.out.println(marley);
		System.out.println("***********************");
		
		System.out.println("pirata");
		Papagaio pirata = new Papagaio();
		pirata.pena = true;
		pirata.voa = true;
		System.out.println(pirata);
		System.out.println("***********************");
		
		System.out.println("croc");
		Jacare croc = new Jacare();
		croc.anda= true;
		croc.nada = true;
		croc.peleFria = true;
		System.out.println(croc);
		System.out.println("***********************");
		
		System.out.println("willy");
		Baleia willy = new Baleia();
		willy.mama = true;
		willy.nada = true;
		System.out.println(willy);	
		System.out.println("***********************");
	
	
	
	
	
	}
		
}
