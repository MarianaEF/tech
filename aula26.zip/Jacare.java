
public class Jacare extends Reptil {
	Boolean nada;
	Boolean anda;

	public Jacare() {

		nada = true;
		anda = true;
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Jacare [nada=" + nada + ", anda=" + anda + ", peleFria=" + peleFria + ", alimenta=" + alimenta
				+ ", vive=" + vive + ", respira=" + respira + ", movimenta=" + movimenta + "]";
	}

}
