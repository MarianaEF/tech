
public class Homem extends Mamiferos {
	Boolean bipede;
public Homem() {
	
	bipede = true;
	// TODO Auto-generated constructor stub
}
	@Override
	public String toString() {
		return "Homem [bipede=" + bipede + ", mama=" + mama + ", alimenta=" + alimenta + ", vive=" + vive + ", respira="
				+ respira + ", movimenta=" + movimenta + "]";
	}

	
}
