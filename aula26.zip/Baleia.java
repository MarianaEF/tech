
public class Baleia extends Mamiferos {
	Boolean nada;

	public Baleia() {

			nada = true;
			respira = false;
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Baleia [nada=" + nada + ", mama=" + mama + ", alimenta=" + alimenta + ", vive=" + vive + ", respira="
				+ respira + ", movimenta=" + movimenta + "]";
	}

}
