
public class Cachorro extends Mamiferos {
	Boolean quadrupede;

	public Cachorro() {

		quadrupede = true;

		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Cachorro [quadrupede=" + quadrupede + ", mama=" + mama + ", alimenta=" + alimenta + ", vive=" + vive
				+ ", respira=" + respira + ", movimenta=" + movimenta + "]";
	}

}
