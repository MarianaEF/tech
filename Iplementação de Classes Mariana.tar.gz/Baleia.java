
public class Baleia extends Mamiferos {
	Boolean nada;
	public String toString() {
		return  "\nmovimeta:"+movimenta+"\n"+"\nalimenta:"+alimenta+"\n"+"\nvive:"+vive+"\n"+"\nnada:"+nada+"\n";
		
	}
}
