
public class Ave extends Animal{
	Boolean pena ;
	
}
