
public class Papagaio extends Ave{
	Boolean voa ;
	public String toString() {
		return  "\nmovimeta:" + movimenta+ "\n"+ "\nalimenta:" + alimenta +"\n"+ "\nvive:" + vive+ "\n"+ "\nvoa:" + voa + "\n";
		
	}
}
