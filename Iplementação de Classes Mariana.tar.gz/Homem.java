
public class Homem extends Animal {
	Boolean bipede;

	public String toString() {
		return "\nmovimeta:" + movimenta + "\n" + "\nalimenta:" + alimenta + " \n" + "\nvive:" + vive +"\n"
				+ "\nbipede:"+bipede +"\n";

	}
}
