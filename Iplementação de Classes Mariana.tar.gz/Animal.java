
public class Animal {
	boolean alimenta;
	boolean vive;
	boolean respira;
	boolean movimenta;
	
}
