
public class Reptil extends Animal {
	Boolean peleFria ;

}
