
public class Mamiferos extends Animal {

	boolean mama;
	
}
