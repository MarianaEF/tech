
public class Jacare extends Reptil {
	Boolean nada ;
	Boolean anda ;
	public String toString() {
		return  "\nmovimeta:" + movimenta + "\n "+ "\nalimenta:" + alimenta+ "\n"+ "\nvive:" + vive +" \n"+ "\nnada:"+ nada+ "\n"+"\nanda:" + anda +" \n";		
	}
}
