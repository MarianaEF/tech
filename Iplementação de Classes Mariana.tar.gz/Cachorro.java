
public class Cachorro extends Animal {
	Boolean quadrupede ;
	public String toString() {
		return  "\nmovimeta:" + movimenta+ "\n"+ "\nalimenta:" + alimenta +"\n"+ "\nvive:" + vive+ "\n"+ "\nquadrupede:"+ quadrupede+"\n";
		
	}
}
