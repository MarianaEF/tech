
public class Lagarto extends Reptil {
	Boolean anda ;
	public String toString() {
		return  "\nmovimeta:" + movimenta+ "\n"+ "\nalimenta:" + alimenta+ "\n"+ "\nvive:" + vive+" \n"+ "\nanda:"+ anda+"\n";
		
	}
}
