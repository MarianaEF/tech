import java.util.Locale.LanguageRange;

public class ProgramaRodar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("jack");
		Lagarto jack = new Lagarto();
		jack.alimenta = true;
		jack.anda = true;
		jack.movimenta = true;
		jack.peleFria = true;
		jack.respira = true;
		jack.vive = true;
		System.out.println(jack);
		System.out.println("***********************");
		
		System.out.println("felipe");
		Homem felipe = new Homem();
		felipe.alimenta = true;
		felipe.bipede = true;
		felipe.movimenta = true;
		felipe.respira = true;
		felipe.vive = true;
		System.out.println(felipe);
		System.out.println("***********************");
		
		System.out.println("marley");
		Cachorro marley = new Cachorro();
		marley.alimenta = true;
		marley.movimenta = true;
		marley.quadrupede = true;
		marley.respira = true;
		marley.vive= true;
		System.out.println(marley);
		System.out.println("***********************");
		
		System.out.println("pirata");
		Papagaio pirata = new Papagaio();
		pirata.alimenta = true;
		pirata.movimenta = true;
		pirata.pena = true;
		pirata.respira = true;
		pirata.vive = true;
		pirata.voa = true;
		System.out.println(pirata);
		System.out.println("***********************");
		
		System.out.println("croc");
		Jacare croc = new Jacare();
		croc.alimenta = true;
		croc.anda= true;
		croc.movimenta = true;
		croc.nada = true;
		croc.peleFria = true;
		croc.respira = true;
		croc.vive = true;
		System.out.println(croc);
		System.out.println("***********************");
		
		System.out.println("willy");
		Baleia willy = new Baleia();
		willy.movimenta = true;
		willy.alimenta = true;
		willy.vive = true;
		willy.mama = true;
		willy.respira = true;
		willy.nada = true;
		System.out.println(willy);	
		System.out.println("***********************");
	
	
	
	
	
	}
		
}
