import java.util.Scanner;

public class CalculoOperacoes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner entrada = new Scanner(System.in);
		
		double adição = 0;
		double subtração = 0 ;
		double multiplicação = 0;
		double divisão = 0;
		

		double numero = 0;
		double numero2 = 0;
		double proxNumero = 0;
		int opcao = 0;
		
		double TotalAdição = 0;
		double TotalSubtração = 0;
		double TotalMultiplicação = 0;
		double TotalDivisão = 0;
		
			do {
				
				System.out.println(" Escolha a operação desejada");
				System.out.println(" 1- Adição, 2-Subtração, 3-Multiplicação, 4 - Divisão, 5 - sair");
				opcao = entrada.nextInt();
				
				if(opcao == 5) {
					break;
				}
				
				System.out.println("Digite o numero:");
				numero = entrada.nextShort();
				System.out.println("Digite o proximo numero:");
				proxNumero = entrada.nextShort();
				
				
				if(opcao == 1) {
					TotalAdição = numero + proxNumero;
					System.out.println("A soma é:"+ TotalAdição);
				}else if (opcao == 2) {
					TotalSubtração = numero - proxNumero;
					System.out.println(" A subtração é:"+ TotalSubtração);
				}else if (opcao == 4) {
					TotalDivisão = numero / proxNumero;
					System.out.println(" A divisão é:"+ TotalDivisão);
				}else if( opcao == 3) {
					TotalMultiplicação = numero * proxNumero;
					System.out.println(" A multiplicação é:"+ TotalMultiplicação);
				}
				
			}while(opcao != 5);
		
		
		
	}

}
