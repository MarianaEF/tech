import java.util.Scanner;

public class PositivosNegativos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner entrada = new Scanner(System.in);
		
		int numero = 0;
		int totalPositivo = 0;
		int totalNegativo= 0;
		int somaPosNeg = 0;
		
		do{ 
			System.out.println(" Digite o numero:");
			numero = entrada.nextInt();
			
			if(numero > 0) {
				totalPositivo = totalPositivo + numero;
			}else {
				totalNegativo = totalNegativo + numero;
			}
			
		}while(numero != 0);
		
		somaPosNeg = totalPositivo + totalNegativo;
		System.out.println(" A soma dos numeros positivos é:"+ totalPositivo);
		System.out.println("A soma dos numeros negativos é:" + totalNegativo);
		System.out.println(" A soma das duas anteriores é:"+ somaPosNeg);
		
	}

}
