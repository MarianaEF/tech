import java.util.Scanner;

public class AlturaIdade {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner entrada = new Scanner(System.in);
		
		int idade=0;
		double altura =0;
		int contMaior50 =0;
		double mediaAlturaMaior50= 0;
		double somaAlturaMaior50 = 0;
		int contIdadeEntre18e50 = 0;
		double somaAlturaEntre18e50 = 0;
		double mediaAlturaEntre18e50=0;
		
		System.out.println(" Informe o numero de pesoas que deseja cadastrar:");
		int numeroPessoas = entrada.nextInt();
		
		for(int contador = 1; contador <= numeroPessoas; contador ++) {
			System.out.println(" Digite a idade:");
			idade = entrada.nextInt();
			
			System.out.println("Digite a altura:");
			altura = entrada.nextDouble();
			
			if(idade > 50) {
				contMaior50 = contMaior50 + 1;
				somaAlturaMaior50 = somaAlturaMaior50 + altura;
			}else if (idade >= 18 && idade <=50) {
				contIdadeEntre18e50 = contIdadeEntre18e50 + 1;
				somaAlturaEntre18e50 = somaAlturaEntre18e50 + altura; 
			}
			
			
		}
		
		mediaAlturaMaior50 = somaAlturaMaior50 / contMaior50;
		mediaAlturaEntre18e50 = somaAlturaEntre18e50 / contIdadeEntre18e50;
		System.out.println(" O total de pessoas com mais de 50 anos são:"+ contMaior50);
		System.out.println(" A média das alturas das pessoas com mais de 50 anos são:"+ mediaAlturaMaior50);
		System.out.println(" O total de pessoas com idades entre 18 e 50 anos é:"+ contIdadeEntre18e50);
		System.out.println(" A média das alturas das pessoas com idades entre 18 e 50 anos são:"+ mediaAlturaEntre18e50);
		
	}

}

